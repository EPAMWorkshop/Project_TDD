package com.epam.app.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.epam.app.entity.Login;
import com.epam.app.entity.PersonEducationDocument;
import com.epam.app.helper.HibernateUtil;

public class LoginDaoImp implements LoginDao {
	SessionFactory sessionFactory=null;
	Session session = null;
	
	public String createLoginTable()
	{
		
	
		try{
			Session session = HibernateUtil.getSessionFactory(Login.class).openSession();
	        session.beginTransaction();
	        
	        Login login=new Login();
			login.setEmailId("abc@abc.com");
			login.setUserID("101a1");
			
			session.save(login);
	        session.getTransaction().commit();
	        HibernateUtil.shutdown(Login.class);
		return "Login Table created";

		}
		catch(Exception e)
		{
			return e.getMessage();
		}
		
		
	}
	
	

	public String getUserID(String emailID) {
		createLoginTable();
		Login loginDetails = null;
		try{
			loginDetails=session.get(Login.class,1);
			return "UserID : "+loginDetails.getUserID();
		}
		catch(Exception e)
		{
			return "message:\"Empty\"";
		}
		
	}
	public String updateUrl(PersonEducationDocument eduDoc) {
		try{
			
			String document_url=//upload
			
			eduDoc.setDocument_url(document_url);
			session.saveOrUpdate(eduDoc);
			return "Successful uploaded";

			}
			catch(Exception e)
			{
				return e.getMessage();
			}
		
	}
	
}
