package com.epam.app.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.epam.app.entity.Login;
import com.epam.app.entity.PersonEducationDocument;
import com.epam.app.helper.HibernateUtil;

public class PersonEducationDocumentDao {
	
	

	
	public String uploadDoc(PersonEducationDocument eduDoc) {
		
		try{
			//upload code
			
			//String of location addUrl
			Session session = HibernateUtil.getSessionFactory(Login.class).openSession();
	        session.beginTransaction();
	        
	        PersonEducationDocument eduDao = new PersonEducationDocument();
	        //eduDao.setUserID(userID);
	        //eduDao.setDocument_url(addUrl);
	        
	        
	        
	        session.saveOrUpdate(eduDoc);
		
	        session.getTransaction().commit();
	        HibernateUtil.shutdown(Login.class);
		return "Successful uploaded";

		}
		catch(Exception e)
		{
			return e.getMessage();
		}
		

		
	}
	
}
