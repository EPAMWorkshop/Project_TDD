package com.epam.app.dao;

public interface LoginDao {
	
	public String getUserID(String emailID);

}
