package com.epam.app.service;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.epam.app.dao.LoginDao;
import com.epam.app.dao.LoginDaoImp;


@Path("/getUserID")
public class GetUserIDService
{
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getUserID() {
		return "message : \"send your email/sessionID\"";
  }
	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String getUserID(@FormParam("email") String email) throws IOException {
		if (email == null) 
		{ 
			return "message : \"email is null\""; 
		}
		else
		{
			LoginDao loginDao=new LoginDaoImp();
			return loginDao.getUserID(email);
		}

   }
    
}
